﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VzOverFlow.Data;
using VzOverFlow.Models;
using VzOverFlow.Models.ViewModels;

namespace VzOverFlow.Services
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<User>> GetUsersAsync(string? search = null)
        {
            var query = _context.Users.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(u =>
                    u.UserName.Contains(search) ||
                    u.Email.Contains(search));
            }

            return await query
                .OrderByDescending(u => u.CreatedAt)
                .ToListAsync();
        }

        public async Task<UserProfileViewModel?> GetUserProfileAsync(int id)
        {
            var user = await _context.Users
                .AsNoTracking()
                .Where(u => u.Id == id)
                .Select(u => new UserProfileViewModel
                {
                    Id = u.Id,
                    UserName = u.UserName,
                    Email = u.Email,
                    CreatedAt = u.CreatedAt,
                    QuestionCount = u.Questions.Count,
                    AnswerCount = u.Answers.Count,
                    Reputation = u.Reputation,
                    TwoFactorEnabled = u.TwoFactorEnabled
                })
                .FirstOrDefaultAsync();

            return user;
        }

        public async Task<IEnumerable<UserProfileViewModel>> GetLeaderboardAsync(int take = 10)
        {
            return await _context.Users
                .AsNoTracking()
                .OrderByDescending(u => u.Reputation)
                .ThenBy(u => u.UserName)
                .Take(take)
                .Select(u => new UserProfileViewModel
                {
                    Id = u.Id,
                    UserName = u.UserName,
                    Email = u.Email,
                    CreatedAt = u.CreatedAt,
                    QuestionCount = u.Questions.Count,
                    AnswerCount = u.Answers.Count,
                    Reputation = u.Reputation,
                    TwoFactorEnabled = u.TwoFactorEnabled
                })
                .ToListAsync();
        }
    }
}
